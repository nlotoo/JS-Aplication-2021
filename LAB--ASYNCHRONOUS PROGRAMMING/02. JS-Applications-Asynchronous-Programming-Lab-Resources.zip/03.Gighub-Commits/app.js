function loadCommits() {
    // Try it with Fetch API
    console.log('TODO...');
}